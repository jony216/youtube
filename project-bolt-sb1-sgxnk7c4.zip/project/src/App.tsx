import React, { useState } from 'react';
import { Menu, Search, Bell, User, Home, Compass, Library, History, PlaySquare, ThumbsUp, Clock } from 'lucide-react';

function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const videos = [
    {
      id: 1,
      thumbnail: "https://images.unsplash.com/photo-1707343843437-caacff5cfa74?w=500&auto=format",
      title: "Beautiful Sunset Time-lapse",
      channel: "Nature Channel",
      views: "120K views",
      timestamp: "2 days ago"
    },
    {
      id: 2,
      thumbnail: "https://images.unsplash.com/photo-1707345512638-997d31a10eaa?w=500&auto=format",
      title: "Cooking Masterclass: Perfect Pasta",
      channel: "Food Masters",
      views: "45K views",
      timestamp: "5 hours ago"
    },
    {
      id: 3,
      thumbnail: "https://images.unsplash.com/photo-1707327956851-30a531b70cda?w=500&auto=format",
      title: "Tech Review: Latest Gadgets",
      channel: "Tech Today",
      views: "200K views",
      timestamp: "1 week ago"
    },
    {
      id: 4,
      thumbnail: "https://images.unsplash.com/photo-1707146009996-7749aa2a0b03?w=500&auto=format",
      title: "Travel Vlog: Hidden Gems",
      channel: "Wanderlust",
      views: "80K views",
      timestamp: "3 days ago"
    },
    {
      id: 5,
      thumbnail: "https://images.unsplash.com/photo-1682687220742-aba19b51f36d?w=500&auto=format",
      title: "Music Production Tutorial",
      channel: "Beat Makers",
      views: "150K views",
      timestamp: "1 day ago"
    },
    {
      id: 6,
      thumbnail: "https://images.unsplash.com/photo-1682687220063-4742bd7fd538?w=500&auto=format",
      title: "Fitness Workshop: Full Body",
      channel: "Fit Life",
      views: "90K views",
      timestamp: "4 days ago"
    }
  ];

  return (
    <div className="min-h-screen bg-[#0f0f0f] text-white">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 bg-[#0f0f0f] h-14 flex items-center justify-between px-4 z-50">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 hover:bg-[#272727] rounded-full"
          >
            <Menu className="w-6 h-6" />
          </button>
          <span className="text-xl font-bold">YouTube</span>
        </div>
        
        <div className="flex-1 max-w-[600px] mx-4">
          <div className="flex">
            <input
              type="text"
              placeholder="Search"
              className="w-full px-4 py-2 bg-[#121212] border border-[#303030] rounded-l-full focus:outline-none focus:border-blue-500"
            />
            <button className="px-6 bg-[#272727] border border-l-0 border-[#303030] rounded-r-full hover:bg-[#3f3f3f]">
              <Search className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button className="p-2 hover:bg-[#272727] rounded-full">
            <Bell className="w-6 h-6" />
          </button>
          <button className="p-2 hover:bg-[#272727] rounded-full">
            <User className="w-6 h-6" />
          </button>
        </div>
      </header>

      {/* Sidebar */}
      <aside className={`fixed left-0 top-14 h-[calc(100vh-56px)] bg-[#0f0f0f] transition-all duration-200 ${isSidebarOpen ? 'w-60' : 'w-20'} z-40`}>
        <div className="p-2">
          <div className="flex flex-col gap-2">
            <button className="flex items-center gap-4 p-2 hover:bg-[#272727] rounded-lg w-full">
              <Home className="w-6 h-6" />
              {isSidebarOpen && <span>Home</span>}
            </button>
            <button className="flex items-center gap-4 p-2 hover:bg-[#272727] rounded-lg w-full">
              <Compass className="w-6 h-6" />
              {isSidebarOpen && <span>Explore</span>}
            </button>
            <button className="flex items-center gap-4 p-2 hover:bg-[#272727] rounded-lg w-full">
              <Library className="w-6 h-6" />
              {isSidebarOpen && <span>Library</span>}
            </button>
            <button className="flex items-center gap-4 p-2 hover:bg-[#272727] rounded-lg w-full">
              <History className="w-6 h-6" />
              {isSidebarOpen && <span>History</span>}
            </button>
            <button className="flex items-center gap-4 p-2 hover:bg-[#272727] rounded-lg w-full">
              <PlaySquare className="w-6 h-6" />
              {isSidebarOpen && <span>Your Videos</span>}
            </button>
            <button className="flex items-center gap-4 p-2 hover:bg-[#272727] rounded-lg w-full">
              <ThumbsUp className="w-6 h-6" />
              {isSidebarOpen && <span>Liked Videos</span>}
            </button>
            <button className="flex items-center gap-4 p-2 hover:bg-[#272727] rounded-lg w-full">
              <Clock className="w-6 h-6" />
              {isSidebarOpen && <span>Watch Later</span>}
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className={`pt-20 ${isSidebarOpen ? 'ml-60' : 'ml-20'} p-6`}>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {videos.map(video => (
            <div key={video.id} className="cursor-pointer">
              <div className="relative">
                <img 
                  src={video.thumbnail} 
                  alt={video.title}
                  className="w-full aspect-video object-cover rounded-xl"
                />
                <div className="absolute bottom-2 right-2 bg-black bg-opacity-80 px-2 py-1 text-xs rounded">
                  4:20
                </div>
              </div>
              <div className="mt-3">
                <h3 className="font-medium line-clamp-2">{video.title}</h3>
                <p className="text-sm text-gray-400 mt-1">{video.channel}</p>
                <div className="text-sm text-gray-400 flex items-center gap-1">
                  <span>{video.views}</span>
                  <span>•</span>
                  <span>{video.timestamp}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}

export default App;